import React from "react";

const Configuracoes = () => {
  return <div>Configuracoes</div>;
};

export default Configuracoes;
