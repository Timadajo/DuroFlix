export default function NotFound() {
  return (
    <>
      <h1>error 404</h1>
    </>
  );
}
