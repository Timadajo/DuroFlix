import React from "react";

export default function Descricao() {
  return (
    <div>
      <h3>Gênero</h3>
      <h3>Duração: </h3>
      <h3>Ano Lancamento: </h3>
      <h3>Plataformas de Streaming: </h3>
      <h3>Nacionalidade: </h3>
      <h3>Sinopse: </h3>
    </div>
  );
}
